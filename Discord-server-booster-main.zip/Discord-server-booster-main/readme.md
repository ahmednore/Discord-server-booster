<h2 align="center">Discord Server: <a href="https://discord.gg/catcha">discord.gg/catcha</a></h2>

<h1><a href="https://www.tiktok.com/@nsl.dev/video/7141125149654256923?is_from_webapp=1&sender_device=pc&web_id=7117334792081442309">Tuto Here</a></h1>

<p align="center">
<strong>Star and follows me <3</strong>
<a href="https://www.youtube.com/channel/UCoNVWCMYp8Fs50wPeefw_7A">Youtube Channel</a></h2>
</p

```
Tokens need to have nitro and need to be on the Server
```

How to run:
```
pip install -r requirements.txt
put boosted tokens in tokens.txt
python3 main.py
```

Advantages:
```
  1.  fast, easy
  2.  free
```
Questions ?
```
Join discord server and ask me...
```
